// Post Document Schema
// this is the post schema, but named question
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const questionSchema = new Schema({//title, text, tags, answers, asked_by, ask_date_time, views
  title: { type: String, required: true, minlength: 1},
  text: {type: String, required: true, minlength:1}, // Content
  type: { type: String, enum: ["text", "link", "media"] }, // Reddit's different posts
  mediaUrl: String,
  subreddit: { type: Schema.Types.ObjectId, ref: "Subreddit" }, // New Schema
  votes: { type: Number, default: 0 },
});

const Question = mongoose.model('Question', questionSchema);
questionSchema.virtual('url').get(function () {
  return '/posts/question/' + this._id;
});

module.exports = Question;