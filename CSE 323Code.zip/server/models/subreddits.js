const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SubredditSchema = new Schema({
    name: { type: String, unique: true },
    description: String,
    moderators: [{ type: Schema.Types.ObjectId, ref: "User" }],
    members: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    created_at: { type: Date, default: Date.now },
    rules: [String],
    banner_url: String,
    icon_url: String
});

const Subreddit = mongoose.model('Subreddit', SubredditSchema);
SubredditSchema.virtual('url').get(function () {
  return '/posts/subreddit/' + this._id;
});

module.exports = Subreddit;

//inside mongodb, column name is subreddits