
## Instructions to setup and run project
On server side, run all the following commands:
npm install
npm install express
npm install mongoose
npm install cors
npm install express-session
npm install connect-mongo
npm install mangodb
npm install bcrypt
node init.js mongodb://127.0.0.1:27017/fake_so
node server.js

On client side, run all the following commands:
npm install
npm install axios
npm start